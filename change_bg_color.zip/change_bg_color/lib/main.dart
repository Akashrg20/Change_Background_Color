import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        textTheme: TextTheme(
          displaySmall: TextStyle(fontWeight: FontWeight.bold,fontSize: 18,color: Colors.black54),
        )


      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});





  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  var bgColor=Colors.white;


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child:  InkWell(
                onTap: () {
                  bgColor=Colors.white;

                  setState(() {

                  });

                },
                child: Icon(Icons.refresh,size: 30,color: Colors.white,)),
          ),
        ],
        title: Text("BG Changer",style: TextStyle(color: Colors.white,letterSpacing: 3,fontSize: 22,fontWeight: FontWeight.w600),),
        backgroundColor: Colors.black45,

      ),
      backgroundColor: bgColor,
      body:  SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 15,vertical: 15),
        scrollDirection: Axis.horizontal,
          child: Align(
            alignment: Alignment.bottomLeft,
            child: Row(
              children: [
                ElevatedButton(
                    onPressed: () {
                      bgColor=Colors.cyan;
                      setState(() {

                      });

                }, child:Text("Cyan")),
                SizedBox(width: 10,),

                ElevatedButton(
                    onPressed: () {
                      bgColor=Colors.orange;
                      setState(() {

                      });

                }, child:Text("Orange")),
                 SizedBox(width: 10,),
                ElevatedButton(
                    onPressed: () {
                      bgColor=Colors.blue;
                      setState(() {

                      });

                    }, child:Text("Blue")),
                 SizedBox(width: 10,),
                ElevatedButton(
                    onPressed: () {
                      bgColor=Colors.red;
                      setState(() {

                      });

                    }, child:Text("Red")),
                 SizedBox(width: 10,),
                ElevatedButton(
                    onPressed: () {
                      bgColor=Colors.deepPurple;
                      setState(() {

                      });

                    }, child:Text("Purple")),
                 SizedBox(width: 10,),
                ElevatedButton(
                    onPressed: () {
                      bgColor=Colors.teal;
                      setState(() {

                      });

                    }, child:Text("Teal")),
                 SizedBox(width: 10,),
                ElevatedButton(
                    onPressed: () {
                      bgColor=Colors.yellow;
                      setState(() {

                      });

                    }, child:Text("Yellow")),
                SizedBox(width: 10,),
                ElevatedButton(
                    onPressed: () {
                      bgColor=Colors.pink;
                      setState(() {

                      });

                    }, child:Text("Pink")),
                SizedBox(width: 10,),
              ],

            ),
          ),
        ),
      );


      

  }

}
